import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryBlue = Color(0xFF007AFF);
  static const Color primaryGreen = Color(0xFF34C759);
}
